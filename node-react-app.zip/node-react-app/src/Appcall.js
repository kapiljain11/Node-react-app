// React frontend component
import { useState, useEffect } from 'react';

function Appcall() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:8080/api/data')
      .then(res => res.json())
      .then(data => {
        setData(data);
        setLoading(false);
      });
  }, []);

  return (
    <div>
      {loading ? 'Loading...' : data.message}
    </div>
  );
}
export default Appcall;