import React from 'react';
import ReactDOM from 'react-dom/client';


//import components
import Appcall from './Appcall.js';
import Mysqlcall from './Mysqlcall.js';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Mysqlcall/>);
