// React frontend component
import { useState, useEffect } from 'react';

function Mysqlcall() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:8080/api/mysqldata')
      .then(res => res.json())
      .then(data => {
        setData(data);
        setLoading(false);
      });
  }, []);

  return (
    <>
	  <table width="100%">
	  <tr>
	  <td>ID</td>
	  <td>Name</td>
	  <td>Email</td>
	  <td>Hobby</td>
	  <td>Gender</td>
	  <td>Status</td>
	  </tr>
      {data &&
        data.fetchdata.map((item) => {
          return <tr key={item.id}><td>{item.id}</td><td>{item.name}</td><td>{item.email}</td><td>{item.hobby}</td><td>{item.gender}</td><td>{item.status}</td></tr>;
        })}
	  </table>	
    </>
  );
}
export default Mysqlcall;