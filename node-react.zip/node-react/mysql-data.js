// Node.js backend (Express)
const express = require('express');
const cors = require('cors');
const app = express();
var mysql = require('mysql');

// Enable CORS for React frontend
app.use(cors());



var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "training"
});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM user WHERE gender = 'male'", function (err, result, fields) {
    if (err) {
		throw err;
	}else{
		app.get('/api/mysqldata', (req, res) => {
		  res.json({ fetchdata: result });
		});

		app.listen(8080, () => {
		  console.log('Server running on port 8080');
		});
		console.log(result);
	}
  });
});



